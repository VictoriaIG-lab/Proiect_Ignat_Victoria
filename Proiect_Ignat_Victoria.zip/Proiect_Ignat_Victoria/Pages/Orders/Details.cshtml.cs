﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Proiect_Ignat_Victoria.Data;
using Proiect_Ignat_Victoria.Models;

namespace Proiect_Ignat_Victoria.Pages.Orders
{
    public class DetailsModel : PageModel
    {
        private readonly Proiect_Ignat_Victoria.Data.Proiect_Ignat_VictoriaContext _context;

        public DetailsModel(Proiect_Ignat_Victoria.Data.Proiect_Ignat_VictoriaContext context)
        {
            _context = context;
        }

        public Order Order { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Order = await _context.Orders.FirstOrDefaultAsync(m => m.Id == id);

            if (Order == null)
            {
                return NotFound();
            }
            return Page();
        }
    }
}
