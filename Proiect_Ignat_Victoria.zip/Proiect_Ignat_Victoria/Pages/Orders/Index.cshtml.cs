﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Proiect_Ignat_Victoria.Data;
using Proiect_Ignat_Victoria.Models;

namespace Proiect_Ignat_Victoria.Pages.Orders
{
    public class IndexModel : PageModel
    {
        private readonly Proiect_Ignat_Victoria.Data.Proiect_Ignat_VictoriaContext _context;

        public IndexModel(Proiect_Ignat_Victoria.Data.Proiect_Ignat_VictoriaContext context)
        {
            _context = context;
        }

        public IList<Order> Order { get;set; }

        public async Task OnGetAsync()
        {
            Order = await _context.Orders.ToListAsync();
        }
    }
}
