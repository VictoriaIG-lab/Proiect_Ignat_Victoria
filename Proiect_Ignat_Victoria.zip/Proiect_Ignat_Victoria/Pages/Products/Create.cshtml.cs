﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Proiect_Ignat_Victoria.Data;
using Proiect_Ignat_Victoria.Models;

namespace Proiect_Ignat_Victoria.Pages.Products
{
    public class CreateModel : PageModel
    {
        private readonly Proiect_Ignat_Victoria.Data.Proiect_Ignat_VictoriaContext _context;

        public CreateModel(Proiect_Ignat_Victoria.Data.Proiect_Ignat_VictoriaContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public Product Product { get; set; }

        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Product.Add(Product);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
