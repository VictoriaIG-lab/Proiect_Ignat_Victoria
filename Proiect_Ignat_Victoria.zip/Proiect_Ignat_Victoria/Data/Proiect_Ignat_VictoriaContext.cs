﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Proiect_Ignat_Victoria.Models;

namespace Proiect_Ignat_Victoria.Data
{
    public class Proiect_Ignat_VictoriaContext : DbContext
    {
        public Proiect_Ignat_VictoriaContext (DbContextOptions<Proiect_Ignat_VictoriaContext> options)
            : base(options)
        {
        }

        public DbSet<Proiect_Ignat_Victoria.Models.Product> Product { get; set; }

        public DbSet<Proiect_Ignat_Victoria.Models.Order> Orders { get; set; }
        public DbSet<Proiect_Ignat_Victoria.Models.Client> Clients { get; set; }

    }
}
