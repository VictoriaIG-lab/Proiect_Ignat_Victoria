﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Proiect_Ignat_Victoria.Models
{
    public class Product
    {
        public int Id { get; set; }
        [Display(Name = "Product name")]

        public string Name { get; set; }
        [Display(Name = "Product category")]
        public string Category { get; set; }

        [Column(TypeName="decimal(6, 2)" )]
        public float Price { get; set; }

        [DataType(DataType.Date)]  //am adaugat o noua proprietate
        public DateTime ExpirationDate { get; set; }
        
    }
}
